<p align="center">**Pirates Party**</p>

<p align="center">
Aplicación para mi amigo daniel con mucho amor con la Ayuda de <a href="https://github.com/ebola182">Jonathan Palacios</a> Desarrollador Front-End
</p>

## Lenguajes
Back-End (MySQL - PHP)

Front-End (
Materialize
Jquery
React-Native)

## Licencia

Codigo abierto [MIT license](http://opensource.org/licenses/MIT).
