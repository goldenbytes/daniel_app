<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Pirate Party</title>
    <link rel="stylesheet" href="<?php echo asset('css/materialize.min.css'); ?>">
    <link rel="stylesheet" href="<?php echo asset('css/font-awesome.min.css'); ?>">
    <link rel="stylesheet" href="<?php echo asset('css/MyCSS.css'); ?>">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0" />
    <link rel="icon" type="image/x-icon" href="http://icons.iconarchive.com/icons/aha-soft/torrent/512/pirate-icon.png" />
  </head>
  <body>

    <div class="fondo3">

  		<div class="cuerpo2">
          <img src=<?php echo asset('Imagenes/logo.png'); ?>  class="responsive-img logo-admin"  alt="Logo de Gorod"/>
        <div class="left-align">
            <div class="row" style="width:100%">
                <ul class="collection">
                  <li class="collection-item avatar">
                    <img src="<?php echo asset('Iconos/pirata.png'); ?>" alt="" class="circle">
                    <span class="title black-text left-aling">Player 1</span>
                    <p>Level # <br>
                       Keyword
                    </p>
                    <a href="#!" class="secondary-content"><i class="fa fa-thumbs-o-up"></i></a>
                  </li>
                  <li class="collection-item avatar">
                    <img src="<?php echo asset('Iconos/pirata.png'); ?>" alt="" class="circle">
                    <span class="title black-text">Player 2</span>
                    <p>Level # <br>
                       Keyword
                    </p>
                    <a href="#!" class="secondary-content"><i class="fa fa-thumbs-o-up"></i></a>
                  </li>
                  <li class="collection-item avatar">
                    <img src="<?php echo asset('Iconos/pirata.png'); ?>" alt="" class="circle">
                    <span class="title black-text">Player 3</span>
                    <p>Level # <br>
                       Keyword
                    </p>
                    <a href="#!" class="secondary-content"><i class="fa fa-thumbs-o-up"></i></a>
                  </li>
                  <li class="collection-item avatar">
                    <img src="<?php echo asset('Iconos/pirata.png'); ?>" alt="" class="circle">
                    <span class="title black-text">Player 4</span>
                    <p>Level # <br>
                       Keyword
                    </p>
                    <b href="#!" class="secondary-content"><i class="fa fa-thumbs-o-up"></i></b>
                  </li>
                </ul>
            </div>
          </div>
  		</div>
  	</div>
    <script type="text/javascript" src="<?php echo asset('js/jquery.min.js'); ?>"></script>
    <script type="text/javascript" src="<?php echo asset('js/materialize.min.js'); ?>"></script>
  </body>
</html>