<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class macht extends Model
{
    protected $table        =   'palabra';
    //protected $primaryKey   =   'id_jug';
    public    $timestamps   =   false;
}
